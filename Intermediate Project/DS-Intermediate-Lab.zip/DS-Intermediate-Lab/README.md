# 📊 Data Science Lab Work – Intermediate Projects

A collection of intermediate-level Data Science projects built in Python, covering Exploratory Data Analysis (EDA), Classification, and Regression. Each project includes clean, well-commented code, custom datasets, and saved visualizations.

---

## 📁 Repository Structure

```
DS-Intermediate-Lab/
│
├── data/
│   ├── ecommerce_customers.csv       # E-Commerce Customer Behavior Dataset
│   ├── student_performance.csv       # Student Academic Performance Dataset
│   └── house_prices.csv              # House Prices Dataset (India)
│
├── notebooks/
│   ├── 01_EDA_Ecommerce_Customer.py        # Project 1 – EDA
│   ├── 02_Classification_Student_Performance.py  # Project 2 – Classification
│   └── 03_Regression_House_Prices.py       # Project 3 – Regression
│
├── outputs/                          # All saved plots (auto-generated)
│
└── README.md
```

---

## 🧪 Projects Overview

### Project 1 – Exploratory Data Analysis (EDA)
**File:** `01_EDA_Ecommerce_Customer.py`  
**Dataset:** `ecommerce_customers.csv`

Performs a full EDA on 50 customers from an e-commerce platform.

**Skills covered:**
- Data loading, inspection, and summarization
- Univariate & bivariate analysis
- Correlation heatmaps
- Hypothesis testing (independent t-test)
- Churn rate analysis by segment
- Pair plots with Seaborn

**Key Libraries:** `pandas`, `numpy`, `matplotlib`, `seaborn`, `scipy`

---

### Project 2 – Classification (Pass/Fail Prediction)
**File:** `02_Classification_Student_Performance.py`  
**Dataset:** `student_performance.csv`

Predicts whether a student will pass or fail their exams using machine learning classifiers.

**Skills covered:**
- Label encoding & ordinal encoding
- Train/test split with stratification
- Feature scaling (StandardScaler)
- Logistic Regression, Decision Tree, Random Forest
- Cross-validation
- Confusion matrix & classification report
- ROC curves & AUC scores
- Feature importance
- Hyperparameter tuning with GridSearchCV

**Key Libraries:** `scikit-learn`, `pandas`, `matplotlib`, `seaborn`

---

### Project 3 – Regression (House Price Prediction)
**File:** `03_Regression_House_Prices.py`  
**Dataset:** `house_prices.csv`

Predicts house prices in Indian cities using multiple regression models.

**Skills covered:**
- Feature engineering (house age, total rooms)
- Log-transformation of the target variable
- Linear Regression, Ridge, Lasso
- Random Forest Regressor, Gradient Boosting Regressor
- R², MAE, RMSE evaluation metrics
- Actual vs Predicted plots
- Residual analysis
- Feature importance from ensemble models

**Key Libraries:** `scikit-learn`, `pandas`, `numpy`, `matplotlib`, `seaborn`

---

## 📦 Datasets

| Dataset | Rows | Target | Task |
|---|---|---|---|
| `ecommerce_customers.csv` | 50 | `Churned` (0/1) | EDA + Churn Analysis |
| `student_performance.csv` | 50 | `Passed` (0/1) | Binary Classification |
| `house_prices.csv` | 40 | `Price_INR` | Regression |

All datasets are custom-generated and representative of real-world patterns.

---

## 🚀 How to Run

### 1. Install dependencies

```bash
pip install pandas numpy matplotlib seaborn scikit-learn scipy
```

### 2. Run any project

```bash
cd notebooks/
python 01_EDA_Ecommerce_Customer.py
python 02_Classification_Student_Performance.py
python 03_Regression_House_Prices.py
```

All output plots are saved automatically to the `outputs/` folder.

---

## 📈 Output Plots Generated

| # | Filename | Project |
|---|---|---|
| 01 | `01_univariate_histograms.png` | EDA |
| 02 | `02_categorical_distributions.png` | EDA |
| 03 | `03_correlation_heatmap.png` | EDA |
| 04 | `04_scatter_bivariate.png` | EDA |
| 05 | `05_boxplots.png` | EDA |
| 06 | `06_pairplot.png` | EDA |
| 07 | `07_confusion_matrices.png` | Classification |
| 08 | `08_roc_curves.png` | Classification |
| 09 | `09_feature_importance.png` | Classification |
| 10 | `10_decision_tree.png` | Classification |
| 11 | `11_price_distribution.png` | Regression |
| 12 | `12_regression_correlation.png` | Regression |
| 13 | `13_area_vs_price.png` | Regression |
| 14 | `14_actual_vs_predicted.png` | Regression |
| 15 | `15_residuals.png` | Regression |
| 16 | `16_regression_feature_importance.png` | Regression |

---

## 🛠 Tech Stack

- **Language:** Python 3.8+
- **Data Manipulation:** Pandas, NumPy
- **Visualization:** Matplotlib, Seaborn
- **Machine Learning:** Scikit-learn
- **Statistics:** SciPy

---

## 📚 Learning Outcomes

After completing these projects, you will be able to:

1. Perform a complete EDA pipeline from raw CSV to insights
2. Preprocess data (encoding, scaling, feature engineering)
3. Train, compare, and evaluate multiple ML models
4. Interpret model outputs (feature importance, confusion matrix, ROC)
5. Apply cross-validation and hyperparameter tuning
6. Handle regression problems including log transformations and residual analysis

---

## 👤 Author

**Piyush Patane**  
Data Science Lab Work – Intermediate Level  

---

## 📄 License

This project is open-source and intended for educational use.
