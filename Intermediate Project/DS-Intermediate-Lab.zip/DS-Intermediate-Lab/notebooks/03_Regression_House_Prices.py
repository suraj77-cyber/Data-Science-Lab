# =============================================================
# PROJECT 3: REGRESSION – House Price Prediction
# Dataset: House Prices (India)
# Level: Intermediate
# =============================================================

# ── IMPORTS ──────────────────────────────────────────────────
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler, PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

import warnings
warnings.filterwarnings('ignore')

plt.style.use('seaborn-v0_8-darkgrid')

# ── 1. LOAD DATA ─────────────────────────────────────────────
df = pd.read_csv('../data/house_prices.csv')

print("=" * 55)
print("   HOUSE PRICE REGRESSION")
print("=" * 55)
print(f"\nShape : {df.shape}")
print(f"\nSample:\n{df.head()}")
print(f"\nPrice Stats (INR):\n{df['Price_INR'].describe()}")

# ── 2. EDA – PRICE DISTRIBUTION ──────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(13, 4))
fig.suptitle('House Price Distribution', fontsize=14, fontweight='bold')

axes[0].hist(df['Price_INR'] / 1e6, bins=12, edgecolor='black', color='steelblue', alpha=0.8)
axes[0].set_title('Price Distribution (Millions INR)')
axes[0].set_xlabel('Price (Millions INR)')
axes[0].set_ylabel('Count')

axes[1].hist(np.log1p(df['Price_INR']), bins=12, edgecolor='black', color='darkorange', alpha=0.8)
axes[1].set_title('Log-Transformed Price')
axes[1].set_xlabel('log(Price)')
axes[1].set_ylabel('Count')

plt.tight_layout()
plt.savefig('../outputs/11_price_distribution.png', dpi=150)
plt.show()
print("✅ Saved: 11_price_distribution.png")

# ── 3. CORRELATION ANALYSIS ──────────────────────────────────
num_cols = ['Area_sqft', 'Bedrooms', 'Bathrooms', 'Floors',
            'GarageSpaces', 'YearBuilt', 'DistanceToCity_km', 'Price_INR']
fig, ax = plt.subplots(figsize=(9, 7))
sns.heatmap(df[num_cols].corr(), annot=True, fmt='.2f', cmap='RdYlGn',
            linewidths=0.5, square=True, ax=ax)
ax.set_title('Feature Correlation Heatmap', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('../outputs/12_regression_correlation.png', dpi=150)
plt.show()
print("✅ Saved: 12_regression_correlation.png")

# ── 4. SCATTER: AREA vs PRICE ────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(13, 5))

axes[0].scatter(df['Area_sqft'], df['Price_INR'] / 1e6,
                c=df['Bedrooms'], cmap='viridis', edgecolors='k', s=70, alpha=0.8)
axes[0].set_xlabel('Area (sqft)')
axes[0].set_ylabel('Price (Millions INR)')
axes[0].set_title('Area vs Price (color = Bedrooms)')

price_by_neigh = df.groupby('Neighborhood')['Price_INR'].mean() / 1e6
axes[1].bar(price_by_neigh.index, price_by_neigh.values,
            color=['#4CAF50', '#2196F3', '#FF5722'], edgecolor='black', alpha=0.85)
axes[1].set_xlabel('Neighborhood')
axes[1].set_ylabel('Avg Price (Millions INR)')
axes[1].set_title('Average Price by Neighborhood')

plt.tight_layout()
plt.savefig('../outputs/13_area_vs_price.png', dpi=150)
plt.show()
print("✅ Saved: 13_area_vs_price.png")

# ── 5. FEATURE ENGINEERING ───────────────────────────────────
df_ml = df.copy()
df_ml['Age_of_House']       = 2024 - df_ml['YearBuilt']
df_ml['Neighborhood']       = LabelEncoder().fit_transform(df_ml['Neighborhood'])
df_ml['HasPool']            = df_ml['HasPool'].map({'No': 0, 'Yes': 1})
df_ml['Renovated']          = df_ml['Renovated'].map({'No': 0, 'Yes': 1})
df_ml['Price_log']          = np.log1p(df_ml['Price_INR'])   # log target
df_ml['Rooms_Total']        = df_ml['Bedrooms'] + df_ml['Bathrooms']

feature_cols = ['Area_sqft', 'Bedrooms', 'Bathrooms', 'Floors', 'GarageSpaces',
                'Age_of_House', 'Neighborhood', 'DistanceToCity_km',
                'HasPool', 'Renovated', 'Rooms_Total']

X = df_ml[feature_cols]
y = df_ml['Price_log']    # Predict log-price for better regression behavior

# ── 6. TRAIN/TEST SPLIT + SCALE ──────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

print(f"\nTrain: {X_train.shape[0]}  |  Test: {X_test.shape[0]}")

# ── 7. TRAIN MULTIPLE REGRESSORS ─────────────────────────────
models = {
    'Linear Regression'      : LinearRegression(),
    'Ridge Regression'       : Ridge(alpha=10),
    'Lasso Regression'       : Lasso(alpha=0.01),
    'Random Forest'          : RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting'      : GradientBoostingRegressor(n_estimators=100, random_state=42)
}

results = {}
print(f"\n{'Model':<25} {'R²':>8} {'MAE (log)':>12} {'RMSE (log)':>12}")
print("-" * 62)

for name, model in models.items():
    use_scaled = name in ['Linear Regression', 'Ridge Regression', 'Lasso Regression']
    Xtr = X_train_sc if use_scaled else X_train
    Xte = X_test_sc  if use_scaled else X_test

    model.fit(Xtr, y_train)
    y_pred = model.predict(Xte)

    r2   = r2_score(y_test, y_pred)
    mae  = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    results[name] = {'model': model, 'pred': y_pred, 'r2': r2, 'mae': mae, 'rmse': rmse,
                     'scaled': use_scaled}
    print(f"{name:<25} {r2:>8.4f} {mae:>12.4f} {rmse:>12.4f}")

# ── 8. ACTUAL vs PREDICTED PLOTS ─────────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle('Actual vs Predicted Log-Price', fontsize=15, fontweight='bold')
axes = axes.flatten()

for i, (name, res) in enumerate(results.items()):
    ax = axes[i]
    ax.scatter(y_test, res['pred'], alpha=0.7, edgecolors='k', s=55, color='steelblue')
    lo, hi = y_test.min(), y_test.max()
    ax.plot([lo, hi], [lo, hi], 'r--', lw=1.5, label='Perfect')
    ax.set_xlabel('Actual log(Price)')
    ax.set_ylabel('Predicted log(Price)')
    ax.set_title(f"{name}\nR² = {res['r2']:.3f}")
    ax.legend(fontsize=8)

axes[-1].axis('off')
plt.tight_layout()
plt.savefig('../outputs/14_actual_vs_predicted.png', dpi=150)
plt.show()
print("✅ Saved: 14_actual_vs_predicted.png")

# ── 9. RESIDUAL ANALYSIS ─────────────────────────────────────
best_name = max(results, key=lambda k: results[k]['r2'])
best      = results[best_name]
residuals = y_test.values - best['pred']

fig, axes = plt.subplots(1, 2, figsize=(13, 5))
fig.suptitle(f'Residual Analysis – {best_name}', fontsize=14, fontweight='bold')

axes[0].scatter(best['pred'], residuals, alpha=0.7, edgecolors='k', s=55, color='darkorange')
axes[0].axhline(0, color='red', linestyle='--', lw=1.5)
axes[0].set_xlabel('Predicted')
axes[0].set_ylabel('Residuals')
axes[0].set_title('Predicted vs Residuals')

axes[1].hist(residuals, bins=10, edgecolor='black', color='mediumseagreen', alpha=0.8)
axes[1].axvline(0, color='red', linestyle='--', lw=1.5)
axes[1].set_xlabel('Residual Value')
axes[1].set_ylabel('Frequency')
axes[1].set_title('Residual Distribution')

plt.tight_layout()
plt.savefig('../outputs/15_residuals.png', dpi=150)
plt.show()
print("✅ Saved: 15_residuals.png")

# ── 10. FEATURE IMPORTANCE (Best Tree Model) ─────────────────
tree_name  = 'Gradient Boosting' if results['Gradient Boosting']['r2'] > results['Random Forest']['r2'] else 'Random Forest'
tree_model = results[tree_name]['model']
importances = pd.Series(tree_model.feature_importances_, index=feature_cols).sort_values()

fig, ax = plt.subplots(figsize=(8, 5))
importances.plot(kind='barh', ax=ax, color='mediumpurple', edgecolor='black')
ax.set_title(f'{tree_name} – Feature Importances', fontsize=14, fontweight='bold')
ax.set_xlabel('Importance Score')
plt.tight_layout()
plt.savefig('../outputs/16_regression_feature_importance.png', dpi=150)
plt.show()
print("✅ Saved: 16_regression_feature_importance.png")

# ── 11. SUMMARY ──────────────────────────────────────────────
print("\n\n📊 Final Model Rankings (R² Score):")
print("-" * 45)
sorted_res = sorted(results.items(), key=lambda x: x[1]['r2'], reverse=True)
for rank, (name, res) in enumerate(sorted_res, 1):
    print(f"  {rank}. {name:<25} R² = {res['r2']:.4f}")

print(f"\n🏆 Best Model: {best_name}  (R² = {best['r2']:.4f})")
print("\n🎉 Regression Project Complete!")
