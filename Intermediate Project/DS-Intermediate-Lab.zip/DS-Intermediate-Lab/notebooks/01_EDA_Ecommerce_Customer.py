# =============================================================
# PROJECT 1: Exploratory Data Analysis (EDA)
# Dataset: E-Commerce Customer Behavior
# Level: Intermediate
# =============================================================

# ── IMPORTS ──────────────────────────────────────────────────
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

# ── 1. LOAD & INSPECT DATA ───────────────────────────────────
df = pd.read_csv('../data/ecommerce_customers.csv')

print("=" * 55)
print("        E-COMMERCE CUSTOMER EDA")
print("=" * 55)
print(f"\n📦 Shape         : {df.shape}")
print(f"📋 Columns       : {list(df.columns)}")
print(f"\n🔍 First 5 rows :\n{df.head()}")
print(f"\n📊 Data Types :\n{df.dtypes}")
print(f"\n✅ Missing Values :\n{df.isnull().sum()}")

# ── 2. DESCRIPTIVE STATISTICS ────────────────────────────────
print("\n📈 Descriptive Statistics:\n")
print(df.describe().round(2))

# ── 3. UNIVARIATE ANALYSIS ───────────────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
fig.suptitle('Univariate Analysis – Numerical Features', fontsize=16, fontweight='bold')

num_cols = ['Age', 'AnnualIncome_INR', 'SpendingScore',
            'MembershipYears', 'PurchasesPerMonth', 'AvgOrderValue_INR']

for ax, col in zip(axes.flatten(), num_cols):
    ax.hist(df[col], bins=12, edgecolor='black', alpha=0.75)
    ax.set_title(col)
    ax.set_xlabel(col)
    ax.set_ylabel('Frequency')

plt.tight_layout()
plt.savefig('../outputs/01_univariate_histograms.png', dpi=150)
plt.show()
print("✅ Saved: 01_univariate_histograms.png")

# ── 4. CATEGORICAL ANALYSIS ──────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle('Categorical Feature Distributions', fontsize=15, fontweight='bold')

cat_cols = ['Gender', 'ProductCategory', 'City']
for ax, col in zip(axes, cat_cols):
    counts = df[col].value_counts()
    ax.bar(counts.index, counts.values, edgecolor='black', alpha=0.8)
    ax.set_title(f'{col} Distribution')
    ax.set_xlabel(col)
    ax.set_ylabel('Count')
    ax.tick_params(axis='x', rotation=30)

plt.tight_layout()
plt.savefig('../outputs/02_categorical_distributions.png', dpi=150)
plt.show()
print("✅ Saved: 02_categorical_distributions.png")

# ── 5. CORRELATION HEATMAP ───────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 7))
corr = df[num_cols + ['Churned']].corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm',
            mask=mask, ax=ax, linewidths=0.5, square=True)
ax.set_title('Correlation Heatmap', fontsize=15, fontweight='bold')
plt.tight_layout()
plt.savefig('../outputs/03_correlation_heatmap.png', dpi=150)
plt.show()
print("✅ Saved: 03_correlation_heatmap.png")

# ── 6. BIVARIATE ANALYSIS ────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('Spending Score vs Income & Age', fontsize=14, fontweight='bold')

scatter1 = axes[0].scatter(df['AnnualIncome_INR'], df['SpendingScore'],
                            c=df['Churned'], cmap='bwr', alpha=0.7, edgecolors='k', s=60)
axes[0].set_xlabel('Annual Income (INR)')
axes[0].set_ylabel('Spending Score')
axes[0].set_title('Income vs Spending Score\n(Red=Churned)')
plt.colorbar(scatter1, ax=axes[0], label='Churned')

scatter2 = axes[1].scatter(df['Age'], df['SpendingScore'],
                            c=df['Churned'], cmap='bwr', alpha=0.7, edgecolors='k', s=60)
axes[1].set_xlabel('Age')
axes[1].set_ylabel('Spending Score')
axes[1].set_title('Age vs Spending Score\n(Red=Churned)')
plt.colorbar(scatter2, ax=axes[1], label='Churned')

plt.tight_layout()
plt.savefig('../outputs/04_scatter_bivariate.png', dpi=150)
plt.show()
print("✅ Saved: 04_scatter_bivariate.png")

# ── 7. BOXPLOT – SPENDING SCORE BY GENDER & CATEGORY ─────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('Spending Score Distribution', fontsize=14, fontweight='bold')

df.boxplot(column='SpendingScore', by='Gender', ax=axes[0])
axes[0].set_title('By Gender')
axes[0].set_xlabel('Gender')
axes[0].set_ylabel('Spending Score')

df.boxplot(column='SpendingScore', by='ProductCategory', ax=axes[1])
axes[1].set_title('By Product Category')
axes[1].set_xlabel('Product Category')
axes[1].set_ylabel('Spending Score')
axes[1].tick_params(axis='x', rotation=30)

plt.tight_layout()
plt.savefig('../outputs/05_boxplots.png', dpi=150)
plt.show()
print("✅ Saved: 05_boxplots.png")

# ── 8. CHURN RATE ANALYSIS ───────────────────────────────────
print("\n\n📊 Churn Rate Analysis:")
print("-" * 40)
churn_rate = df['Churned'].mean() * 100
print(f"Overall Churn Rate  : {churn_rate:.1f}%")

print("\nChurn by Product Category:")
churn_by_cat = df.groupby('ProductCategory')['Churned'].mean().sort_values(ascending=False)
print((churn_by_cat * 100).round(1).to_string())

print("\nChurn by City:")
churn_by_city = df.groupby('City')['Churned'].mean().sort_values(ascending=False)
print((churn_by_city * 100).round(1).to_string())

# ── 9. HYPOTHESIS TEST: Age vs Churned ───────────────────────
print("\n\n📐 Statistical Test – Age & Churn:")
print("-" * 40)
churned = df[df['Churned'] == 1]['Age']
retained = df[df['Churned'] == 0]['Age']
t_stat, p_val = stats.ttest_ind(churned, retained)
print(f"Churned Avg Age    : {churned.mean():.1f}")
print(f"Retained Avg Age   : {retained.mean():.1f}")
print(f"T-statistic        : {t_stat:.3f}")
print(f"P-value            : {p_val:.4f}")
if p_val < 0.05:
    print("➡  Significant difference (p < 0.05) – Age is a churn indicator.")
else:
    print("➡  No significant difference (p ≥ 0.05).")

# ── 10. PAIR PLOT ────────────────────────────────────────────
pair_df = df[['Age', 'SpendingScore', 'AnnualIncome_INR', 'PurchasesPerMonth', 'Churned']].copy()
pair_df['Churned'] = pair_df['Churned'].map({0: 'Retained', 1: 'Churned'})
g = sns.pairplot(pair_df, hue='Churned', palette={'Retained': '#2196F3', 'Churned': '#F44336'}, diag_kind='kde')
g.figure.suptitle('Pair Plot – Customer Features by Churn Status', y=1.02, fontsize=14)
plt.savefig('../outputs/06_pairplot.png', dpi=120)
plt.show()
print("✅ Saved: 06_pairplot.png")

print("\n🎉 EDA Complete! All plots saved to /outputs/")
