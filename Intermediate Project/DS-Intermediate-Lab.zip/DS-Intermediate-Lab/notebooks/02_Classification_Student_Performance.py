# =============================================================
# PROJECT 2: CLASSIFICATION – Student Pass/Fail Prediction
# Dataset: Student Academic Performance
# Level: Intermediate
# =============================================================

# ── IMPORTS ──────────────────────────────────────────────────
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, classification_report,
                              confusion_matrix, roc_curve, auc, ConfusionMatrixDisplay)

import warnings
warnings.filterwarnings('ignore')

plt.style.use('seaborn-v0_8-darkgrid')

# ── 1. LOAD DATA ─────────────────────────────────────────────
df = pd.read_csv('../data/student_performance.csv')

print("=" * 55)
print("   STUDENT PASS/FAIL CLASSIFICATION")
print("=" * 55)
print(f"\nShape: {df.shape}")
print(f"\nClass Distribution:\n{df['Passed'].value_counts()}")
print(f"\nPass Rate: {df['Passed'].mean()*100:.1f}%")

# ── 2. PREPROCESSING ─────────────────────────────────────────
print("\n\n⚙️  Preprocessing...")

df_enc = df.copy()
le = LabelEncoder()

# Encode binary categoricals
for col in ['Gender', 'InternetAccess', 'Tutoring', 'Renovated']:
    if col in df_enc.columns:
        df_enc[col] = le.fit_transform(df_enc[col])

# Encode ordinal: ParentalSupport
support_map = {'Low': 0, 'Medium': 1, 'High': 2}
df_enc['ParentalSupport'] = df_enc['ParentalSupport'].map(support_map)

# Encode Gender and binary flags
df_enc['Gender']        = df['Gender'].map({'Male': 0, 'Female': 1})
df_enc['InternetAccess']= df['InternetAccess'].map({'No': 0, 'Yes': 1})
df_enc['Tutoring']      = df['Tutoring'].map({'No': 0, 'Yes': 1})

print("Encoded DataFrame head:\n", df_enc.head())

# ── 3. FEATURE SELECTION ─────────────────────────────────────
feature_cols = ['Gender', 'Age', 'StudyHoursPerDay', 'AttendancePercent',
                'PreviousScore', 'InternetAccess', 'Tutoring', 'ParentalSupport']
X = df_enc[feature_cols]
y = df_enc['Passed']

# ── 4. TRAIN/TEST SPLIT ──────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y)

print(f"\nTrain size: {X_train.shape[0]}  |  Test size: {X_test.shape[0]}")

# Scale features
scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

# ── 5. TRAIN MULTIPLE CLASSIFIERS ────────────────────────────
models = {
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
    'Decision Tree'      : DecisionTreeClassifier(max_depth=4, random_state=42),
    'Random Forest'      : RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
}

results = {}
print("\n\n📊 Model Performance Summary:")
print(f"{'Model':<25} {'Accuracy':>10} {'CV Mean':>10} {'CV Std':>10}")
print("-" * 60)

for name, model in models.items():
    if name == 'Logistic Regression':
        model.fit(X_train_sc, y_train)
        y_pred = model.predict(X_test_sc)
    else:
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    cv  = cross_val_score(model, X, y, cv=5, scoring='accuracy')
    results[name] = {'model': model, 'pred': y_pred, 'acc': acc, 'cv': cv}
    print(f"{name:<25} {acc:>10.3f} {cv.mean():>10.3f} {cv.std():>10.3f}")

# ── 6. BEST MODEL – DETAILED EVALUATION ─────────────────────
best_name = max(results, key=lambda k: results[k]['acc'])
best      = results[best_name]
print(f"\n\n🏆 Best Model: {best_name}")
print("\n📋 Classification Report:\n")
print(classification_report(y_test, best['pred'], target_names=['Failed', 'Passed']))

# ── 7. CONFUSION MATRIX ──────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(16, 4))
fig.suptitle('Confusion Matrices – All Models', fontsize=14, fontweight='bold')

for ax, (name, res) in zip(axes, results.items()):
    cm = confusion_matrix(y_test, res['pred'])
    disp = ConfusionMatrixDisplay(cm, display_labels=['Failed', 'Passed'])
    disp.plot(ax=ax, colorbar=False, cmap='Blues')
    ax.set_title(name)

plt.tight_layout()
plt.savefig('../outputs/07_confusion_matrices.png', dpi=150)
plt.show()
print("✅ Saved: 07_confusion_matrices.png")

# ── 8. ROC CURVE ─────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 6))
colors = ['#2196F3', '#4CAF50', '#FF5722']

for (name, res), color in zip(results.items(), colors):
    m = res['model']
    if name == 'Logistic Regression':
        probs = m.predict_proba(X_test_sc)[:, 1]
    else:
        probs = m.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, probs)
    roc_auc = auc(fpr, tpr)
    ax.plot(fpr, tpr, color=color, lw=2, label=f'{name} (AUC = {roc_auc:.2f})')

ax.plot([0, 1], [0, 1], 'k--', lw=1, label='Random')
ax.set_xlabel('False Positive Rate', fontsize=12)
ax.set_ylabel('True Positive Rate', fontsize=12)
ax.set_title('ROC Curves – All Models', fontsize=14, fontweight='bold')
ax.legend(loc='lower right', fontsize=11)
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('../outputs/08_roc_curves.png', dpi=150)
plt.show()
print("✅ Saved: 08_roc_curves.png")

# ── 9. FEATURE IMPORTANCE (Random Forest) ───────────────────
rf_model = results['Random Forest']['model']
importances = pd.Series(rf_model.feature_importances_, index=feature_cols).sort_values()

fig, ax = plt.subplots(figsize=(8, 5))
importances.plot(kind='barh', ax=ax, color='steelblue', edgecolor='black')
ax.set_title('Random Forest – Feature Importances', fontsize=14, fontweight='bold')
ax.set_xlabel('Importance Score')
ax.axvline(x=0.1, color='red', linestyle='--', alpha=0.6, label='Threshold = 0.10')
ax.legend()
plt.tight_layout()
plt.savefig('../outputs/09_feature_importance.png', dpi=150)
plt.show()
print("✅ Saved: 09_feature_importance.png")

# ── 10. DECISION TREE VISUALIZATION ──────────────────────────
dt_model = results['Decision Tree']['model']
fig, ax = plt.subplots(figsize=(18, 7))
plot_tree(dt_model, feature_names=feature_cols, class_names=['Fail', 'Pass'],
          filled=True, rounded=True, fontsize=9, ax=ax)
ax.set_title('Decision Tree Structure (max_depth=4)', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('../outputs/10_decision_tree.png', dpi=120)
plt.show()
print("✅ Saved: 10_decision_tree.png")

# ── 11. HYPERPARAMETER TUNING (Random Forest) ────────────────
print("\n\n🔧 Hyperparameter Tuning – Random Forest...")
param_grid = {
    'n_estimators': [50, 100, 150],
    'max_depth'   : [3, 5, 7],
}
grid = GridSearchCV(RandomForestClassifier(random_state=42), param_grid, cv=5, scoring='accuracy')
grid.fit(X_train, y_train)
print(f"Best Params  : {grid.best_params_}")
print(f"Best CV Score: {grid.best_score_:.4f}")
final_pred = grid.best_estimator_.predict(X_test)
print(f"Test Accuracy: {accuracy_score(y_test, final_pred):.4f}")

print("\n\n🎉 Classification Project Complete!")
